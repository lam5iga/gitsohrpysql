from conn import connection
import pymysql
tf = True
while tf:

    try:

        with connection:
            with connection.cursor() as cur:
                while True:
                    x = int(input("Введите номер телефона: +79"))
                    sel1 = f"select phone from customers where phone = {x}"
                    cur.execute(sel1)
                    if cur.fetchall():
                        c = input("пароль:")
                        cur.execute(f"select phone, password from customers where phone = {x} and password = '{c}'")
                        if cur.fetchall():
                            print('Вы успешно авторизировались')
                            tf=False
                            break
                        else:
                            print("Неверный пароль")
                    else:
                        print('Неверный номер телефона')
    except:
        with connection:
            print("CR")
            print(connection.cursor.fetchall())

