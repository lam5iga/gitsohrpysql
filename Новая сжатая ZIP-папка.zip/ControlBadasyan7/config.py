localhost = '3306'
user = 'root'
password = 'root'
database = 'controlbank'