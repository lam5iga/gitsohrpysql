# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
from conn import connection
ladkj = "select * from transactions"

try:
    with connection:
        with connection.cursor() as cur:
            cur.execute(ladkj)
            connection.commit()
            print("conection successful")
except Exception as ex:
    print("Connection Refused")
